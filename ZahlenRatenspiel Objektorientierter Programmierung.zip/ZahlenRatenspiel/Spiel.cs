﻿namespace ZahlenRatenspiel
{
    public class Spiel
    {
        private int gepseicherteZahl;
        private int versuche;       

        public Spiel(int min, int max)
        {
            Random random = new Random();
            gepseicherteZahl = random.Next(min, max + 1);
            versuche = 0;
        }

        public void start()
        {
            bool wiederspielen = true;

            while (wiederspielen)
            {
                Console.WriteLine("Welcome to our Number-Guessing game.");            

                while (true)
                {
                    int eingabeZahl = gerateneZahl();
                    versuche++;

                    if (eingabeZahl == gepseicherteZahl)
                    {
                        Console.WriteLine("Congratulation. You have guessed the correct number. You needed " + versuche + " tries.");
                        Console.WriteLine("Do you want to play again? y or n? ");
                        string antwort = Convert.ToString(Console.ReadLine());

                        if (antwort == "y")
                        {
                            versuche = 0;
                            gepseicherteZahl = new Random().Next(1, 101);
                        }
                        else if (antwort == "n")
                        {
                            wiederspielen = false;
                            break;
                        }
                    }
                    else if (eingabeZahl < gepseicherteZahl)
                    {
                        Console.WriteLine("The number, which you have guessed, is too low.");
                    }
                    else
                    {
                        Console.WriteLine("The number, which you have guessed, is too high");
                    }
                }
            }
        }

        public int gerateneZahl()
        {
            int eingabe;
            bool gueltigeEingabe = false;

            do
            {
                Console.WriteLine("Please give us a number between 1 and 100: ");
                gueltigeEingabe = int.TryParse(Console.ReadLine(), out eingabe);
                if (!gueltigeEingabe || eingabe < 0 || eingabe > 100)
                {
                    Console.WriteLine("This Number is invalid. Try again!.");
                }
            } while (!gueltigeEingabe || eingabe < 0 || eingabe > 100);

            return eingabe;
        }
    }
}
