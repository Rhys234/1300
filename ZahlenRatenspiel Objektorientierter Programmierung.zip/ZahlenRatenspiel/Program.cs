﻿using ZahlenRatenspiel;

class Program
{
    static void Main(string[] args)
    {
        Spiel zahlenraten = new Spiel(1, 100);
        zahlenraten.start();
    }
}
