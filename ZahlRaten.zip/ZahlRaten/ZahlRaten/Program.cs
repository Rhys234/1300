﻿using System;

namespace ZahlRaten;

class program
{

    static void Main(string[] args)
    {
        Random geheimZahl = new Random();
        int i = geheimZahl.Next(1, 100);
        bool win = false;
        int versuche = 0;

        try
        {
            Console.WriteLine("Welcome to our Number-Guessing game.");

            do
            {
                Console.WriteLine("Please give us a number between 1 and 100: ");
                int eingabezahl = Convert.ToInt32(Console.ReadLine());
                
                if (i < eingabezahl)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("The number, which you have guessed, is too high");
                    versuche = versuche + 1;
                    Console.ResetColor();
                }

                else if (i > eingabezahl)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("The number, which you have guessed, is too low.");
                    versuche = versuche + 1;
                    Console.ResetColor();

                }
                else if (i == eingabezahl)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Congratulation. You have guessed the correct number. You needed " + versuche + " tries.");
                    Console.ResetColor();

                    Console.WriteLine("Do you want to play again? y or n? ");
                    string antwort = Convert.ToString(Console.ReadLine());

                    if (antwort == "y")
                    {
                        i = geheimZahl.Next(1, 100);

                    }
                    else if (antwort == "n")
                    {
                        Environment.Exit(0);
                    }
                }

            } while (win == false);

        }
        catch
        {
            Console.WriteLine("This entry is invalid. Please restart the program!.");
            Environment.Exit(0);
        }
        
    }

}